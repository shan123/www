<?php
require_once 'Spreadsheet/Excel/Writer.php';

//DNS Variables
$domainV = $_POST['domain'];
$rusernameV = $_POST['rusername'];
$dregistrarV = $_POST['dregistrar'];
$dnsusernameV = $_POST['dnsusername'];
$dnsproviderV = $_POST['dnsprovider'];
$dnsserverV = $_POST['dnsserver'];

echo $domainV . "   " . $rusernameV . "   " . $dregistrarV  . "   " . $dnsusernameV . "   " . $dnsproviderV . "   " .   $dnsserverV . "<br>";
?>